To use this builder:


- Drag & drop a .ckb file onto the CKBtoWAV.exe to convert the .ckb to a .wav.
- Make any necessary edits & save the file as a .wav.
- Copy & paste the edited .wav into the corresponding version of your Windows OS.
- Copy the entire name of the .wav, open the batch file in a Notepad App, & paste over the input.wav. output.ckb
should just be the same name, but remove the .wav extension when copy-pasting.
- Save the batch file & run it.
- Profit.